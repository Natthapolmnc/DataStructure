

class BST {
    private BTNode root;

    BST(){
        this.root=null;
    }

    /**
     * @return the root
     */
    private BTNode getRoot() {
        return root;
    }

    /**
     * @param root the root to set
     */
    private void setRoot(BTNode root) {
        this.root = root;
    }

    public boolean contain(int element){
        return getNode(element)!=null;
    }

    public void add(int newElement) {
        if(this.root==null){
            this.root=new BTNode(newElement,null,null);
        }
        if(this.root!=null){
        BTNode p = root;
        while (p.getLeft() != null && p.getRight() != null) {
            if (p.getElement() == newElement) {
                return;
            } else if (p.getElement() < newElement) {
                p = p.getRight();
            } else if (p.getElement() > newElement) {
                p = p.getLeft();
            }
        }
        if (newElement > p.getElement()) {
            p.setRight(new BTNode(newElement, null, null));
        } else if (newElement < p.getElement()) {
            p.setLeft(new BTNode(newElement, null, null));
        }}
    }

    public BTNode getNode(int element) {
        BTNode p=this.root;
        while (p.getLeft() != null && p.getRight() != null) {
            if (p.getElement()==element) {
                return p;
            } else if (p.getElement() < element) {
                p = p.getRight();
            } else if (p.getElement() > element) {
                p = p.getLeft();
            }
        }
        return null;
    }

    public int getMax() {
        BTNode p = root;
        while (p.getRight() != null) {
            p = p.getRight();
        }
        return p.getElement();
    }

    public int getMin() {
        BTNode p = root;
        while (p.getLeft() != null) {
            p = p.getLeft();
        }
        return p.getElement();
    }

    public int nnodes(){
       return numNode(this.root);
    }

    public int numNode(BTNode n){
        if (n==null){
            return 0;
        }else {
            return 1+numNode(n.getLeft())+numNode(n.getRight());
        }
    }

    public void printTree(){
        printInorder(this.root);
    }

    public void printInorder(BTNode p){
        if (p!=null){
            printInorder(p.getLeft());
            System.out.print(p.getElement()+",");
            printInorder(p.getRight());
        }
    }


}